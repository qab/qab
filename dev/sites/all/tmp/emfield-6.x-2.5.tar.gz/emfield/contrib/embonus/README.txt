Embedded Media Bonus Pack
=========================

This will add additional field info to your embedded media fields.

Currently, it will add a start & end time option to supported video providers.

Supported providers include Media: PBS, which will display only the clip
specified by that time when set.
