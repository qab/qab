
THIS MODULE INTENTIONALLY LEFT BLANK.

NOTICE: image_ncck has been replaced by emimage. If you follow the upgrade instructions properly,
i.e., you disable your modules in d5 before upgrading to d6, you should have no problems.
