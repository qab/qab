
/********************/
 Embedded Wave Field
/********************/

Author: Noah Biavaschi

Requires: Drupal 6, Content (CCK), Embedded Media Field
Optional: Views

This extensible module will create a field for node content types that can be used to display waves from providers
such as google.
