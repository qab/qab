<?php
  $attributes['class'] .= ' views_slideshow_pager_thumbnails';
?>
<div<?php print drupal_attributes($attributes); ?>></div>
