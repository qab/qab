<?php
  $attributes['class'] .= ' views_slideshow_pager_numbered';
?>
<div<?php print drupal_attributes($attributes); ?>></div>
