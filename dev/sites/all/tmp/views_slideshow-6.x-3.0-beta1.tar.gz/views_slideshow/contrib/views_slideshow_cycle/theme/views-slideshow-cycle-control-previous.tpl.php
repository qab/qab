<?php print $rendered_previous_link; ?>
