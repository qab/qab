// $Id: README.txt,v 1.1.2.1.2.1 2010/02/23 23:07:04 psynaptic Exp $

Views Slideshow: ThumbnailHover
================================

This mode allows full nodes and node teasers to be used as both the slideshow
and the control for advancing the slideshow.

It is the original alternative slideshow mode for Views Slideshow.


Description
===========

The Views Slideshow: ThumbnailHover adds two parts to the view: a series of
items displayed as a list and either full nodes or node teasers as the controls.

The slide show will synchronize the two, so that the 'active' item will
correspond to the single full/teaser item.

The slide show can be set to automatically advance on mouse hover or click.
