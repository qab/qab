<?php
// $Id: panels-dashboard.tpl.php,v 1.1.2.5 2010/10/19 21:12:30 merlinofchaos Exp $
?>
<div class="panels-dashboard">
  <div class="dashboard-left clear-block">
    <?php print $left; ?>
  </div>

  <div class="dashboard-right clear-block">
    <?php print $right; ?>
  </div>
</div>
