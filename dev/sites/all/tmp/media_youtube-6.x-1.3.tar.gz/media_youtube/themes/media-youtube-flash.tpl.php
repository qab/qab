<?php
// $Id: media-youtube-flash.tpl.php,v 1.1.2.2 2010/11/12 14:43:11 aaron Exp $

/**
 * @file media_youtube/themes/media-youtube-flash.tpl.php
 *
 * Template file for Media: YouTube's theme('media_youtube_flash').
 *
 * This will display YouTube's embedded video.
 */
?>
<div id="media-youtube-<?php print $id; ?>" class="<?php print $classes; ?>">
  <?php print $output; ?>
</div>
