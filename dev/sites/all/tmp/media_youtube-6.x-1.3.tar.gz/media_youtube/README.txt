// $Id: README.txt,v 1.1.2.1 2010/02/19 00:42:19 aaron Exp $

Media: YouTube

Provides support for YouTube videos to the Embedded Media Field module,
available at http://drupal.org/project/emfield. Install that and the included
Embedded Video Field module.
