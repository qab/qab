<div <?php print drupal_attributes($attributes); ?>>
  <span class="num">1</span> <?php print t('of'); ?> <span class="total"><?php print count($rows); ?></span>
</div>
