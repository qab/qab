<span <?php print drupal_attributes($attributes); ?>><a href="#"><?php print $start_text; ?></a></span>
